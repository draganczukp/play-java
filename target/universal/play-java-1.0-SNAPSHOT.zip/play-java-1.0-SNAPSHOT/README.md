#play-java

This is the main repo for my attempts at creating a Web Site using [Play Framework](playframework.com), [Thymeleaf 2](thymeleaf.org) and [Bootstrap 3](getbootstrap.com).

#Non-standard libraries
####libraries not included by default with Play
 * Thymeleaf 2 
 * Bootstrap 3